<?php

namespace Laracart\Review\Interfaces;

interface ReviewRepositoryInterface
{
}
