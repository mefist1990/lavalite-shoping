<div class="box box-warning">
    <div class="box-header with-border">
        <h3 class="box-title">  {!! trans('review::review.names') !!} [{!! trans('review::review.text.preview') !!}]</h3>
        <div class="box-tools pull-right">
           <!--  <button type="button" class="btn btn-primary btn-sm"  data-action='NEW' data-load-to='#review-review-entry' data-href='{!!trans_url('admin/review/review/create')!!}'><i class="fa fa-plus-circle"></i> {{ trans('app.new') }} </button> -->
        </div>
    </div>
</div>