<?php

namespace Laracart\Product\Interfaces;

interface ProductRepositoryInterface
{
}
