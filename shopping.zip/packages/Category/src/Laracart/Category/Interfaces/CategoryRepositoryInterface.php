<?php

namespace Laracart\Category\Interfaces;

interface CategoryRepositoryInterface
{
}
