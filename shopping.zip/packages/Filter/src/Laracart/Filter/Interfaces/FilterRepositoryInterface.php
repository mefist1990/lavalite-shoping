<?php

namespace Laracart\Filter\Interfaces;

interface FilterRepositoryInterface
{
}
