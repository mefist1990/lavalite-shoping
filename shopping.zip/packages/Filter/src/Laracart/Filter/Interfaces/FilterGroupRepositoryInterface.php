<?php

namespace Laracart\Filter\Interfaces;

interface FilterGroupRepositoryInterface
{
}
