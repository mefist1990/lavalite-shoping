<?php

namespace Laracart\Filter\Providers;

use Illuminate\Contracts\Auth\Access\Gate as GateContract;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the package.
     *
     * @var array
     */
    protected $policies = [
        // Bind Filter policy
        \Laracart\Filter\Models\Filter::class => \Laracart\Filter\Policies\FilterPolicy::class,
// Bind FilterGroup policy
        \Laracart\Filter\Models\FilterGroup::class => \Laracart\Filter\Policies\FilterGroupPolicy::class,
    ];

    /**
     * Register any package authentication / authorization services.
     *
     * @param \Illuminate\Contracts\Auth\Access\Gate $gate
     *
     * @return void
     */
    public function boot(GateContract $gate)
    {
        parent::registerPolicies($gate);
    }
}
