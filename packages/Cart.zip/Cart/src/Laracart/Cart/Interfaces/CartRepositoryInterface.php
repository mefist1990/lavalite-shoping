<?php

namespace Laracart\Cart\Interfaces;

interface CartRepositoryInterface
{
}
