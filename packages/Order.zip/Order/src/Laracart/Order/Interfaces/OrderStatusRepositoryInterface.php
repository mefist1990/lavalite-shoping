<?php

namespace Laracart\Order\Interfaces;

interface OrderStatusRepositoryInterface
{
}
