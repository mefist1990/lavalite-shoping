<?php

namespace Laracart\Attribute\Interfaces;

interface AttributeRepositoryInterface
{
}
