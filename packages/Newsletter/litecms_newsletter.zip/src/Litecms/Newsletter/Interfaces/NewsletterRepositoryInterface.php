<?php

namespace Litecms\Newsletter\Interfaces;

interface NewsletterRepositoryInterface
{
}
