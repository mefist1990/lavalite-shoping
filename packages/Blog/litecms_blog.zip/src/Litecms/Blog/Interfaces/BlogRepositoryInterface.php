<?php

namespace Litecms\Blog\Interfaces;

interface BlogRepositoryInterface
{
}
