<?php

namespace Litecms\Blog\Interfaces;

interface CategoryRepositoryInterface
{
}
