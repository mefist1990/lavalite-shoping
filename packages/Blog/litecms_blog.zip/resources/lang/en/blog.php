<?php

return [

    /**
     * Singlular and plural name of the module
     */
    'name'          => 'Blog',
    'names'         => 'Blogs',
    'title'       => [
        'user'  => 'My Blogs',
        'admin' => 'Blogs',
        'sub'   => [
            'user'  => 'Blogs created by me',
            'admin' => 'Blogs',
        ],
    ],

    /**
     * Options for select/radio/check.
     */
    'options'       => [
            'status'              => ['show','hide'],
    ],

    /**
     * Placeholder for inputs
     */
    'placeholder'   => [
        'category_id'                => 'Please enter category_id',
        'title'                      => 'Please enter title',
        'details'                    => 'Please enter details',
        'image'                      => 'Please enter image',
        'images'                     => 'Please enter images',
        'viewcount'                  => 'Please enter viewcount',
        'status'                     => 'Please enter status',
        'posted_on'                  => 'Please enter posted_on',
    ],

    /**
     * Labels for inputs.
     */
    'label'         => [
        'category_id'                => 'Category id',
        'title'                      => 'Title',
        'details'                    => 'Details',
        'image'                      => 'Image',
        'images'                     => 'Images',
        'viewcount'                  => 'Viewcount',
        'status'                     => 'Status',
        'posted_on'                  => 'Posted on',
        'status'                     => 'Status',
        'created_at'                 => 'Created at',
        'updated_at'                 => 'Updated at',
    ],

    /**
     * Tab labels
     */
    'tab'           => [
        'name'  => 'Name',
    ],

    /**
     * Texts  for the module
     */
    'text'          => [
        'preview' => 'Click on the below list for preview',
    ],
];
