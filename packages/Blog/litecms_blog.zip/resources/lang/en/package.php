<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Label language files for Menus Module
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default labels for menus module,
    | and it is used by the template/view files in this module
    |
    */

    'name'          => 'Blog',
    'names'         => 'Blogs',
];
