<div class='col-md-4 col-sm-6'>
                       {!! Form::text('category_id')
                       -> label(trans('blog::blog.label.category_id'))
                       -> placeholder(trans('blog::blog.placeholder.category_id'))!!}
                </div>

                <div class='col-md-4 col-sm-6'>
                       {!! Form::text('title')
                       -> label(trans('blog::blog.label.title'))
                       -> placeholder(trans('blog::blog.placeholder.title'))!!}
                </div>

                <div class='col-md-4 col-sm-6'>
                       {!! Form::text('details')
                       -> label(trans('blog::blog.label.details'))
                       -> placeholder(trans('blog::blog.placeholder.details'))!!}
                </div>

                <div class='col-md-4 col-sm-6'>
                       {!! Form::text('image')
                       -> label(trans('blog::blog.label.image'))
                       -> placeholder(trans('blog::blog.placeholder.image'))!!}
                </div>

                <div class='col-md-4 col-sm-6'>
                       {!! Form::text('images')
                       -> label(trans('blog::blog.label.images'))
                       -> placeholder(trans('blog::blog.placeholder.images'))!!}
                </div>

                <div class='col-md-4 col-sm-6'>
                       {!! Form::text('viewcount')
                       -> label(trans('blog::blog.label.viewcount'))
                       -> placeholder(trans('blog::blog.placeholder.viewcount'))!!}
                </div>

                <div class='col-md-4 col-sm-6'>
                       {!! Form::text('status')
                       -> label(trans('blog::blog.label.status'))
                       -> placeholder(trans('blog::blog.placeholder.status'))!!}
                </div>

                <div class='col-md-4 col-sm-6'>
                       {!! Form::text('posted_on')
                       -> label(trans('blog::blog.label.posted_on'))
                       -> placeholder(trans('blog::blog.placeholder.posted_on'))!!}
                </div>

{!!   Form::actions()
->large_primary_submit('Submit')
->large_inverse_reset('Reset')
!!}