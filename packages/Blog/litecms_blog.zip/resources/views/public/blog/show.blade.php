<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="card-box">
                <div class="row">
                    <div class="col-md-6">
                        <h4 class="text-dark  header-title m-t-0"> {!! $blog['name'] !!} </h4>
                    </div>
                    <div class="col-md-6">
                        <a href="{{ trans_url('blogs') }}" class="btn btn-default pull-right"> app.back</a>
                    </div>
                </div>
                <hr/>

                <div class="row">
        <div class="col-md-4 col-sm-6">
            <div class"form-group">
                <label for="category_id">
                    {!! trans('blog::blog.label.category_id') !!}
                </label><br />
                    {!! $blog['category_id'] !!}
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class"form-group">
                <label for="title">
                    {!! trans('blog::blog.label.title') !!}
                </label><br />
                    {!! $blog['title'] !!}
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class"form-group">
                <label for="details">
                    {!! trans('blog::blog.label.details') !!}
                </label><br />
                    {!! $blog['details'] !!}
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class"form-group">
                <label for="image">
                    {!! trans('blog::blog.label.image') !!}
                </label><br />
                    {!! $blog['image'] !!}
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class"form-group">
                <label for="images">
                    {!! trans('blog::blog.label.images') !!}
                </label><br />
                    {!! $blog['images'] !!}
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class"form-group">
                <label for="viewcount">
                    {!! trans('blog::blog.label.viewcount') !!}
                </label><br />
                    {!! $blog['viewcount'] !!}
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class"form-group">
                <label for="status">
                    {!! trans('blog::blog.label.status') !!}
                </label><br />
                    {!! $blog['status'] !!}
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class"form-group">
                <label for="posted_on">
                    {!! trans('blog::blog.label.posted_on') !!}
                </label><br />
                    {!! $blog['posted_on'] !!}
            </div>
        </div>
    </div>
            </div>  
        </div>  
        <div class="col-md-4">
            @include('blog::public.blog.aside')
        </div>

    </div>
</div>