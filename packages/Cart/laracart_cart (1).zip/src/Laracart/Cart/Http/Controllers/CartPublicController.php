<?php

namespace Laracart\Cart\Http\Controllers;

use App\Http\Controllers\PublicController as BaseController;
use Laracart\Cart\Interfaces\CartRepositoryInterface;

class CartPublicController extends BaseController
{
    // use CartWorkflow;

    /**
     * Constructor.
     *
     * @param type \Laracart\Cart\Interfaces\CartRepositoryInterface $cart
     *
     * @return type
     */
    public function __construct(CartRepositoryInterface $cart)
    {
        $this->repository = $cart;
        parent::__construct();
    }

    /**
     * Show cart's list.
     *
     * @param string $slug
     *
     * @return response
     */
    protected function index()
    {
        $carts = $this->repository
        ->pushCriteria(app('Litepie\Repository\Criteria\RequestCriteria'))
        ->scopeQuery(function($query){
            return $query->orderBy('id','DESC');
        })->paginate();

        return $this->theme->of('cart::public.cart.index', compact('carts'))->render();
    }

    /**
     * Show cart.
     *
     * @param string $slug
     *
     * @return response
     */
    protected function show($slug)
    {
        $cart = $this->repository->scopeQuery(function($query) use ($slug) {
            return $query->orderBy('id','DESC')
                         ->where('slug', $slug);
        })->first(['*']);

        return $this->theme->of('cart::public.cart.show', compact('cart'))->render();
    }

}
