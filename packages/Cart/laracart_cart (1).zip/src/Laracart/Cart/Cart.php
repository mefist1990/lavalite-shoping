<?php

namespace Laracart\Cart;

use User;

class Cart
{
    /**
     * $cart object.
     */
    protected $cart;

    /**
     * Constructor.
     */
    public function __construct(\Laracart\Cart\Interfaces\CartRepositoryInterface $cart)
    {
        $this->cart = $cart;
    }

    /**
     * Returns count of cart.
     *
     * @param array $filter
     *
     * @return int
     */
    public function count()
    {
        return  0;
    }

    /**
     * Make gadget View
     *
     * @param string $view
     *
     * @param int $count
     *
     * @return View
     */
    public function gadget($view = 'admin.cart.gadget', $count = 10)
    {

        if (User::hasRole('user')) {
            $this->cart->pushCriteria(new \Litepie\Laracart\Repositories\Criteria\CartUserCriteria());
        }

        $cart = $this->cart->scopeQuery(function ($query) use ($count) {
            return $query->orderBy('id', 'DESC')->take($count);
        })->all();

        return view('cart::' . $view, compact('cart'))->render();
    }
}
